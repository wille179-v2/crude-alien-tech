local utils = require("utils")

utils.add_recipes("cat-somethings-rumbling",{"EMfoundryexp-base-casting-engine","EMfoundryexp-base-casting-ammunition"})
utils.add_recipes("rocket-silo",{"EMfoundryexp-base-casting-space-platform-foundation"})